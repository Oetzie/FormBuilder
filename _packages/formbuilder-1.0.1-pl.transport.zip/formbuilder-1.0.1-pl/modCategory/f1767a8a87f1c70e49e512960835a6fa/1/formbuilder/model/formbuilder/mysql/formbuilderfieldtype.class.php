<?php

/**
 * Form Builder
 *
 * Copyright 2021 by Oene Tjeerd de Bruin <modx@oetzie.nl>
 */

require_once dirname(__DIR__) . '/formbuilderfieldtype.class.php';

class FormBuilderFieldType_mysql extends FormBuilderFieldType
{
}
