<?php

/**
 * Form Builder
 *
 * Copyright 2021 by Oene Tjeerd de Bruin <modx@oetzie.nl>
 */

require_once dirname(__DIR__) . '/formbuilderform.class.php';

class FormBuilderForm_mysql extends FormBuilderForm
{
}
