<?php

/**
 * Form Builder
 *
 * Copyright 2021 by Oene Tjeerd de Bruin <modx@oetzie.nl>
 */

require_once dirname(__DIR__) . '/formbuilderformfield.class.php';

class FormBuilderFormField_mysql extends FormBuilderFormField
{
}
